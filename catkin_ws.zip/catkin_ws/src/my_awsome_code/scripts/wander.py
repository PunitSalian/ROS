#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist



cmd_vel_pub=rospy.Publisher('cmd_vel',Twist,queue_size=1)
rospy.init_node('stop_forward_robot')
stop_twist=Twist()
forward_twist=Twist()
forward_twist.linear.x=0.5

driving_cmd=False
change_state_time=rospy.Time.now()

rate=rospy.Rate(10)


while not rospy.is_shutdown():
    if driving_cmd:
        cmd_vel_pub.publish(forward_twist)
    else:
        cmd_vel_pub.publish(stop_twist)

    if(change_state_time<rospy.Time.now()):
        driving_cmd=not driving_cmd
        change_state_time=rospy.Time.now()+rospy.Duration(5)

    rate.sleep()
        
