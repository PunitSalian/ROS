#! /usr/bin/env python
import actionlib
import rospy
import time
from my_awsome_code.msg import TimingAction,TimingGoal,TimingFeedback,TimingResult


def do_timer(goal):
        start=time.time()
        updates=0

        if goal.time_to_wait.to_sec()>60.0:
            result=TimingResult()
            result.time_elapsed=rospy.Duration.from_sec(time.time()-start)
            result.updates_sent=updates
            server.set_aborted(resut,"Time too long wait")
            return




        while  (time.time()-start)<goal.time_to_wait.to_sec():
            if server.is_preempt_requested():
                    result=TimingResult()
                    result.time_elapsed=rospy.Duration_from_sec(time.time()-start)
                    result.updates_sent=updates
                    server.set_preempted(result,"Goal preempted")
                    return



            feedback=TimingFeedback()
            feedback.time_elapsed=rospy.Duration.from_sec(time.time()-start)
            feedback.time_remaining=goal.time_to_wait-feedback.time_elapsed
            server.publish_feedback(feedback)
            updates+=1

            time.sleep(1.0)

        result=TimingResult()
        result.time_elapsed=rospy.Duration.from_sec(time.time()-start)
        result.updates_sent=updates
        server.set_succeeded(result,"goal accomplished");

rospy.init_node('timing_service')
server=actionlib.SimpleActionServer('timer',TimingAction,do_timer,False)
server.start()
rospy.spin()











                       
