
"use strict";

let Numpy = require('./Numpy.js');

module.exports = {
  Numpy: Numpy,
};
